$(document).ready(function(){
$(".summernote").summernote();
});