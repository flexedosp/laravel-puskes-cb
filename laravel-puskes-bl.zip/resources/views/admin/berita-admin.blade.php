@extends('layouts.admin')
@section('container-admin')
<section>
    <div>
        <form method="post">
            <textarea class="summernote" id="isiBerita" name="isiBerita"></textarea>
          </form>
    </div>
</section>
@endsection