
<?php $__env->startSection('container-admin'); ?>
    <section>
        <div class="main-panel">
            <div class="main-header">
                <div class="main-header-logo">
                    <!-- Logo Header -->
                    <div class="logo-header" data-background-color="dark">
                        <a href="index.html" class="logo">
                            <img src="assets/img/kaiadmin/logo_light.svg" alt="navbar brand" class="navbar-brand"
                                height="20" />
                        </a>
                        <div class="nav-toggle">
                            <button class="btn btn-toggle toggle-sidebar">
                                <i class="gg-menu-right"></i>
                            </button>
                            <button class="btn btn-toggle sidenav-toggler">
                                <i class="gg-menu-left"></i>
                            </button>
                        </div>
                        <button class="topbar-toggler more">
                            <i class="gg-more-vertical-alt"></i>
                        </button>
                    </div>
                    <!-- End Logo Header -->
                </div>
                <!-- Navbar Header -->
                <?php if (isset($component)) { $__componentOriginal4eb1d04e08b5b091961d415111a15a66 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4eb1d04e08b5b091961d415111a15a66 = $attributes; } ?>
<?php $component = App\View\Components\NavbarAdmin::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navbar-admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\NavbarAdmin::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4eb1d04e08b5b091961d415111a15a66)): ?>
<?php $attributes = $__attributesOriginal4eb1d04e08b5b091961d415111a15a66; ?>
<?php unset($__attributesOriginal4eb1d04e08b5b091961d415111a15a66); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4eb1d04e08b5b091961d415111a15a66)): ?>
<?php $component = $__componentOriginal4eb1d04e08b5b091961d415111a15a66; ?>
<?php unset($__componentOriginal4eb1d04e08b5b091961d415111a15a66); ?>
<?php endif; ?>
                <!-- End Navbar -->
            </div>

            <div class="container">
                <div class="page-inner">
                    <div class="ms-auto">
<button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#ModalFormModul" onclick="ViewTambahModul()">Tambah Modul</button>
                    </div>
                    <div class="my-4">
                        <table id="TableModul" class="table table-striped shadow-sm">
                            <thead>
                                <tr>
                                    <td>No</td>
                                    <td>Aksi</td>
                                    <td>Nama</td>
                                    <td>Status Terbit</td>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
            <?php if (isset($component)) { $__componentOriginalb700c7600e14c39606daa981be9166bf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb700c7600e14c39606daa981be9166bf = $attributes; } ?>
<?php $component = App\View\Components\ModalViewModul::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal-view-modul'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ModalViewModul::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb700c7600e14c39606daa981be9166bf)): ?>
<?php $attributes = $__attributesOriginalb700c7600e14c39606daa981be9166bf; ?>
<?php unset($__attributesOriginalb700c7600e14c39606daa981be9166bf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb700c7600e14c39606daa981be9166bf)): ?>
<?php $component = $__componentOriginalb700c7600e14c39606daa981be9166bf; ?>
<?php unset($__componentOriginalb700c7600e14c39606daa981be9166bf); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal8beab9c3a17722994bd6629a32c58770 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8beab9c3a17722994bd6629a32c58770 = $attributes; } ?>
<?php $component = App\View\Components\ModalFormModul::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal-form-modul'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ModalFormModul::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8beab9c3a17722994bd6629a32c58770)): ?>
<?php $attributes = $__attributesOriginal8beab9c3a17722994bd6629a32c58770; ?>
<?php unset($__attributesOriginal8beab9c3a17722994bd6629a32c58770); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8beab9c3a17722994bd6629a32c58770)): ?>
<?php $component = $__componentOriginal8beab9c3a17722994bd6629a32c58770; ?>
<?php unset($__componentOriginal8beab9c3a17722994bd6629a32c58770); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalba2734afff004ff527a44007b3505ae7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalba2734afff004ff527a44007b3505ae7 = $attributes; } ?>
<?php $component = App\View\Components\FooterAdmin::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer-admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FooterAdmin::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalba2734afff004ff527a44007b3505ae7)): ?>
<?php $attributes = $__attributesOriginalba2734afff004ff527a44007b3505ae7; ?>
<?php unset($__attributesOriginalba2734afff004ff527a44007b3505ae7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba2734afff004ff527a44007b3505ae7)): ?>
<?php $component = $__componentOriginalba2734afff004ff527a44007b3505ae7; ?>
<?php unset($__componentOriginalba2734afff004ff527a44007b3505ae7); ?>
<?php endif; ?>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Personal\Source_Code\Laravel\laravel-puskes-bl\resources\views/admin/modul-admin.blade.php ENDPATH**/ ?>