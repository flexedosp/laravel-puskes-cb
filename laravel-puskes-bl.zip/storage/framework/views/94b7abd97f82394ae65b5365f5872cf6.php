

<?php $__env->startSection('container'); ?>
    <section class="vw-100 vh-auto sectionKonten">
        <h2 class="fw-bold text-center">Halaman Berita</h2>
        <div class="container">
            <form id="searchForm" action="<?php echo e(route('guest.berita')); ?>" method="GET">
                <div id="inputSearchBerita" class="input-group mb-3">
                    <input type="text" class="form-control" id="cariBerita" name="cariBerita" placeholder="Masukkan Judul atau Tanggal . . ."
                        aria-label="Recipient's username" aria-describedby="button-addon2"
                        value="<?php echo e(request('cariBerita')); ?>">
                    <button class="btn btn-outline-primary fs-6" type="submit" id="button-addon2"><i
                            class="fa-solid fa-magnifying-glass"></i></button>
                </div>
            </form>

            <div class="d-flex flex-wrap justify-content-center align-items-center">
                <?php $__currentLoopData = $dataBerita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginalb00a121bed7e155d37851bac37705bbc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb00a121bed7e155d37851bac37705bbc = $attributes; } ?>
<?php $component = App\View\Components\CardBerita::resolve(['gambar' => ''.e($b->gambar).'','judul' => ''.e($b->nama).'','deskripsi' => ''.e($b->deskripsi).'','slug' => ''.e($b->slug).'','date' => ''.e($b->created_at->toDateString()).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card-berita'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\CardBerita::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb00a121bed7e155d37851bac37705bbc)): ?>
<?php $attributes = $__attributesOriginalb00a121bed7e155d37851bac37705bbc; ?>
<?php unset($__attributesOriginalb00a121bed7e155d37851bac37705bbc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb00a121bed7e155d37851bac37705bbc)): ?>
<?php $component = $__componentOriginalb00a121bed7e155d37851bac37705bbc; ?>
<?php unset($__componentOriginalb00a121bed7e155d37851bac37705bbc); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="d-flex justify-content-center">
                <?php echo e($dataBerita->links('vendor.pagination.bootstrap-5')); ?>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Personal\Source_Code\Laravel\laravel-puskes-bl\resources\views/guests/berita.blade.php ENDPATH**/ ?>