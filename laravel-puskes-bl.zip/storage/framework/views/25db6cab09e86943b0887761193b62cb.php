<?php $__env->startSection('container-auth'); ?>
<section>
    <?php if(session('errorLogin')): ?>
    <div class="d-flex justify-content-center mx-auto">
        <div class="alert alert-danger alert-dismissible fade show mt-3" role="alert">
            <?php echo e(session('errorLogin')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    </div>
<?php endif; ?>

    <div id="divLoginAdmin" class="mx-auto bg-white rounded shadow position-absolute top-50 start-50 translate-middle">
        <div id="logoLogin" class="d-flex justify-content-center">
            <img src="/img/logo_curug_bitung.png" class="img-login" alt="Logo Curug Bitung">
            <img src="/img/logo_banten.png" class="img-login" alt="Logo Banten">
            <img src="/img/logo_puskes_cb.png" class="img-login" alt="Logo Puskesmas Curugbitung">
            <img src="/img/logo_kemenkes.png" class="img-login" alt="Logo Kemenkes">
        </div>
        <div id="formLogin">
            <h3 class="fw-bold text-center">Login Admin</h3>
            <form action="<?php echo e(route('admin.check')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <!-- Email -->
                <div class="mb-3">
                    <label for="emailAdmin" class="form-label">Email</label>
                    <input type="email" class="form-control" id="emailAdmin" name="emailAdmin"
                        placeholder="Masukkan email Anda" value="<?php echo e(old('emailAdmin')); ?>">
                </div>

                <div class="mb-3">
                    <label for="passwordAdmin" class="form-label">Password</label>
                    <input type="password" class="form-control" id="passwordAdmin" name="passwordAdmin"
                        placeholder="Masukkan password Anda" value="<?php echo e(old('passwordAdmin')); ?>">
                    
                </div>
                <!-- Tombol Submit -->
                <div class="d-flex justify-content-center">
                    <button type="submit" class="btn btn-primary w-50">Login</button>
                </div>
            </form>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Personal\Source_Code\Laravel\laravel-puskes-bl\resources\views/auth/login.blade.php ENDPATH**/ ?>