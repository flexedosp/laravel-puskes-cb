<?php $__env->startSection('container'); ?>
    <section id="detailBerita" class="container">
        <p class="fs-2 fw-bold mb-1"><?php echo e($dataBerita->nama); ?></p>
        <p class="fw-normal">Penulis <?php echo e($dataBerita->created_by); ?> | Dibuat pada tanggal <?php echo e($dataBerita->created_at->toDateString()); ?></p>
       <div class="d-flex justify-content-center my-3">
           <img src="/img/<?php echo e($dataBerita->gambar); ?>" class="rounded" style="width: 500px; height:auto" alt="">
       </div>
        <p class="font-semibold px-3"><?php echo $dataBerita->deskripsi; ?></p>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Personal\Source_Code\Laravel\laravel-puskes-bl\resources\views/guests/detailBerita.blade.php ENDPATH**/ ?>