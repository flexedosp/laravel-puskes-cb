<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e($titlePage); ?></title>
    <meta content="width=device-width, initial-scale=1.0, shrink-to-fit=no" name="viewport" />
    
    <link rel="shortcut icon" href="/img/logo_puskes_cb.png" type="image/png">

    <!-- Fonts and icons -->
    <script src="/vendor/kaiadminlite1.0.0/assets/js/plugin/webfont/webfont.min.js"></script>
    <script>
        WebFont.load({
            google: {
                families: ["Public Sans:300,400,500,600,700"]
            },
            custom: {
                families: [
                    "Font Awesome 5 Solid",
                    "Font Awesome 5 Regular",
                    "Font Awesome 5 Brands",
                    "simple-line-icons",
                ],
                urls: ["/vendor/kaiadminlite1.0.0/assets/css/fonts.min.css"],
            },
            active: function() {
                sessionStorage.fonts = true;
            },
        });
    </script>

    <!-- CSS Files -->
    <link rel="stylesheet" href="/vendor/kaiadminlite1.0.0/assets/css/bootstrap.min.css" />
    
    <link rel="stylesheet" href="/vendor/summernote/summernote-lite.min.css">
    <link rel="stylesheet" href="/vendor/kaiadminlite1.0.0/assets/css/plugins.min.css" />
    <link rel="stylesheet" href="/vendor/kaiadminlite1.0.0/assets/css/kaiadmin.min.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.12.0/dist/sweetalert2.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="/css/admin_styles.css">
</head>

<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--END Sidebar -->

        <!-- Main Panel -->
        <?php echo $__env->yieldContent('container-admin'); ?>
        <!-- END Main Panel -->


    </div>
    <!--   Core JS Files   -->
    <script src="/vendor/kaiadminlite1.0.0/assets/js/core/jquery-3.7.1.min.js"></script>
    <script src="/vendor/kaiadminlite1.0.0/assets/js/core/popper.min.js"></script>
    <script src="/vendor/kaiadminlite1.0.0/assets/js/core/bootstrap.min.js"></script>
    <!-- Summernote JS -->
    <script src="/vendor/summernote/summernote-lite.min.js"></script>
    
    <!-- jQuery Scrollbar -->
    <script src="/vendor/kaiadminlite1.0.0/assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>

    <!-- Chart JS -->
    <script src="/vendor/kaiadminlite1.0.0/assets/js/plugin/chart.js/chart.min.js"></script>

    <!-- jQuery Sparkline -->
    <script src="/vendor/kaiadminlite1.0.0/assets/js/plugin/jquery.sparkline/jquery.sparkline.min.js"></script>

    <!-- Chart Circle -->
    <script src="/vendor/kaiadminlite1.0.0/assets/js/plugin/chart-circle/circles.min.js"></script>

    <!-- Datatables -->
    <script src="/vendor/kaiadminlite1.0.0/assets/js/plugin/datatables/datatables.min.js"></script>

    <!-- Bootstrap Notify -->
    <script src="/vendor/kaiadminlite1.0.0/assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>

    <!-- jQuery Vector Maps -->
    <script src="/vendor/kaiadminlite1.0.0/assets/js/plugin/jsvectormap/jsvectormap.min.js"></script>
    <script src="/vendor/kaiadminlite1.0.0/assets/js/plugin/jsvectormap/world.js"></script>

    <!-- Sweet Alert -->
    
    


    <!-- Sweet Alert 2-->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.12.0/dist/sweetalert2.all.min.js"></script>

    <!-- Kaiadmin JS -->
    <script src="/vendor/kaiadminlite1.0.0/assets/js/kaiadmin.min.js"></script>
    
    <!-- Custom JS -->
    
    <?php if (isset($component)) { $__componentOriginal0d4a0c41eb8988e0f5044d67455daf58 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0d4a0c41eb8988e0f5044d67455daf58 = $attributes; } ?>
<?php $component = App\View\Components\ScriptAdmin::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('script-admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ScriptAdmin::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0d4a0c41eb8988e0f5044d67455daf58)): ?>
<?php $attributes = $__attributesOriginal0d4a0c41eb8988e0f5044d67455daf58; ?>
<?php unset($__attributesOriginal0d4a0c41eb8988e0f5044d67455daf58); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0d4a0c41eb8988e0f5044d67455daf58)): ?>
<?php $component = $__componentOriginal0d4a0c41eb8988e0f5044d67455daf58; ?>
<?php unset($__componentOriginal0d4a0c41eb8988e0f5044d67455daf58); ?>
<?php endif; ?>

    <script>
        $("#lineChart").sparkline([102, 109, 120, 99, 110, 105, 115], {
            type: "line",
            height: "70",
            width: "100%",
            lineWidth: "2",
            lineColor: "#177dff",
            fillColor: "rgba(23, 125, 255, 0.14)",
        });

        $("#lineChart2").sparkline([99, 125, 122, 105, 110, 124, 115], {
            type: "line",
            height: "70",
            width: "100%",
            lineWidth: "2",
            lineColor: "#f3545d",
            fillColor: "rgba(243, 84, 93, .14)",
        });

        $("#lineChart3").sparkline([105, 103, 123, 100, 95, 105, 115], {
            type: "line",
            height: "70",
            width: "100%",
            lineWidth: "2",
            lineColor: "#ffa534",
            fillColor: "rgba(255, 165, 52, .14)",
        });
    </script>
</body>

</html>
<?php /**PATH D:\Personal\Source_Code\Laravel\laravel-puskes-bl\resources\views/layouts/admin.blade.php ENDPATH**/ ?>