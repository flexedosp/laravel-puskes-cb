

<?php $__env->startSection('container'); ?>
    <section class="sectionKonten vw-100 vh-auto" >
      <h2 class="fw-bold text-center">Halaman Modul</h2>
        <div class="container">
          <form id="searchForm" action="<?php echo e(route('guest.modul')); ?>" method="GET">
            <div id="inputSearchModul" class="input-group mb-3">
                <input type="text" class="form-control" id="cariModul" name="cariModul" placeholder="Masukkan Judul atau Tanggal" aria-label="Recipient's username" aria-describedby="button-addon2">
                <button class="btn btn-outline-primary fs-6" type="submit" id="button-addon2"><i class="fa-solid fa-magnifying-glass"></i></button>
              </div>
          </form>
              <div class="d-flex flex-wrap justify-content-center align-items-center">
                  <?php $__currentLoopData = $dataModul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if (isset($component)) { $__componentOriginalb82b153bb21e26b118072e902fa8cecd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb82b153bb21e26b118072e902fa8cecd = $attributes; } ?>
<?php $component = App\View\Components\CardModul::resolve(['gambar' => ''.e($m->gambar).'','judul' => ''.e($m->nama).'','deskripsi' => ''.e($m->deskripsi).'','slug' => ''.e($m->slug).'','date' => ''.e($m->createdAt).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card-modul'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\CardModul::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb82b153bb21e26b118072e902fa8cecd)): ?>
<?php $attributes = $__attributesOriginalb82b153bb21e26b118072e902fa8cecd; ?>
<?php unset($__attributesOriginalb82b153bb21e26b118072e902fa8cecd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb82b153bb21e26b118072e902fa8cecd)): ?>
<?php $component = $__componentOriginalb82b153bb21e26b118072e902fa8cecd; ?>
<?php unset($__componentOriginalb82b153bb21e26b118072e902fa8cecd); ?>
<?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>

              <div class="d-flex justify-content-center">
                <?php echo e($dataModul->links('vendor.pagination.bootstrap-5')); ?>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Personal\Source_Code\Laravel\laravel-puskes-bl\resources\views/guests/modul.blade.php ENDPATH**/ ?>