<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['dataBerita']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['dataBerita']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div>
    <div id="carouselExample" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
            
            
            <div class="carousel-item vh-100 active">
                <img src="/img/tentang_kami/pengurus_puskesmas.jpeg" class="d-block w-100 h-100 img-carousel" alt="Gambar Carousel" style="object-fit: cover;">
                <div class="position-absolute top-50 start-50 translate-middle text-white">
                    <p class="text-center fs-1 fw-bold text-wrap">Selamat Datang di Website<br> Puskesmas Curugbitung</p>
                    <p class="text-center fs-3 fw-semibold">Curugbitung...bisa!</p>
                </div>
            </div>
            <?php $__currentLoopData = $dataBerita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="carousel-item vh-100 ">
                <img src="/img/<?php echo e($d->gambar); ?>" class="d-block w-100 h-100 img-carousel" alt="Gambar Carousel" style="object-fit: cover;">
                <div class="position-absolute top-50 start-50 translate-middle text-white">
                    <p class="text-center fs-3 fw-bold text-wrap"><?php echo e($d->nama); ?></p>
                    <p class="text-center fw-semibold"><?php echo e(substr($d->deskripsi, 0, 40)); ?>...</p>
                <a class="d-flex justify-content-center a-text-undecorat-white fs-6" href="/berita/<?php echo e($d->slug); ?>">Baca Selengkapnya</a>
                </div>
            </div>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
        <button class="carousel-control-prev bg-white" style="top: 38%; height:100px; width:50px" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
            
            <i class="fa-solid fa-chevron-left text-primary fs-1"></i>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next bg-white" style="top: 38%; height:100px; width:50px" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
            
            <i class="fa-solid fa-chevron-right text-primary fs-1"></i>
            <span class="visually-hidden">Next</span>
        </button>
    </div>    
</div>
<?php /**PATH D:\Personal\Source_Code\Laravel\laravel-puskes-bl\resources\views/components/carousel.blade.php ENDPATH**/ ?>