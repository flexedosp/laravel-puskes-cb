<div>
    <!-- The best way to take care of the future is to take care of the present moment. - Thich Nhat Hanh -->
    <div data-aos="flip-right" class="card m-3" style="width: 18rem; height:24rem;">
        <img src="/img/<?php echo e($gambar); ?>" class="card-img-top" alt="Gambar Berita">
        <div class="card-body">
            <h5 class="card-title"><?php echo e($judul); ?></h5>
          <p class="card-text bg-body-tertiary rounded p-2"><?php echo e((strlen($judul) > 48) ? substr($deskripsi, 0, 20) : substr($deskripsi, 0, 40)); ?>...</p>
          <a href="/berita/<?php echo e($slug); ?>">Baca Selengkapnya</a>
          <hr>
          <p class="card-text"><small class="text-body-secondary">Dibuat pada tanggal <?php echo e($date); ?></small></p>
        </div>
      </div>
</div><?php /**PATH D:\Personal\Source_Code\Laravel\laravel-puskes-bl\resources\views/components/card-berita.blade.php ENDPATH**/ ?>