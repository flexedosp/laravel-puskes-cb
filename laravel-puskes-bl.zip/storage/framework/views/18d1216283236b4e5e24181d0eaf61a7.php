



<?php $__env->startSection('container'); ?>

<section class="vw-100 vh-auto">
    <?php if (isset($component)) { $__componentOriginald411e7576d4af0110009e8a312b749d6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411e7576d4af0110009e8a312b749d6 = $attributes; } ?>
<?php $component = App\View\Components\Carousel::resolve(['dataBerita' => $dataBerita] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('carousel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Carousel::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411e7576d4af0110009e8a312b749d6)): ?>
<?php $attributes = $__attributesOriginald411e7576d4af0110009e8a312b749d6; ?>
<?php unset($__attributesOriginald411e7576d4af0110009e8a312b749d6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411e7576d4af0110009e8a312b749d6)): ?>
<?php $component = $__componentOriginald411e7576d4af0110009e8a312b749d6; ?>
<?php unset($__componentOriginald411e7576d4af0110009e8a312b749d6); ?>
<?php endif; ?>
    </section>

    <section id="card-section" class="vw-100 mx-auto px-3">
        <div id="cardContainer" class="my-5">
            <?php $__currentLoopData = $dataModul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if (isset($component)) { $__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal740c66ff9bbfcb19a96a45ba2fa42d64 = $attributes; } ?>
<?php $component = App\View\Components\Card::resolve(['judul' => $m->nama,'isi' => substr($m->deskripsi, 0, 40),'gambar' => $m->gambar,'slug' => $m->slug,'tgl' => 'Dibuat pada tanggal '. $m->created_at->toDateString()] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal740c66ff9bbfcb19a96a45ba2fa42d64)): ?>
<?php $attributes = $__attributesOriginal740c66ff9bbfcb19a96a45ba2fa42d64; ?>
<?php unset($__attributesOriginal740c66ff9bbfcb19a96a45ba2fa42d64); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64)): ?>
<?php $component = $__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64; ?>
<?php unset($__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Personal\Source_Code\Laravel\laravel-puskes-bl\resources\views/guests/home.blade.php ENDPATH**/ ?>